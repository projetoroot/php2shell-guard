#!/bin/bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
OUT=${1:-"$ROOT/php2shell-guard_1.0.0_all.deb"}
find "$ROOT/pkg" -type d -exec chmod g-s {} +
find "$ROOT/pkg" -type d -exec chmod 755 {} +
find "$ROOT/pkg" -type d -exec chmod g-s {} +
find "$ROOT/pkg" -type f -exec chmod 644 {} +
chmod 755 "$ROOT/pkg/usr/sbin/php2shell-guard" "$ROOT/pkg/usr/local/sbin/apache-multipart-guard"
chmod 755 "$ROOT/pkg/DEBIAN"
chmod 644 "$ROOT/pkg/DEBIAN/control" "$ROOT/pkg/DEBIAN/copyright"
bash -n "$ROOT/pkg/usr/sbin/php2shell-guard"
bash -n "$ROOT/pkg/usr/local/sbin/apache-multipart-guard"
dpkg-deb --root-owner-group --build "$ROOT/pkg" "$OUT"
dpkg-deb --info "$OUT"
sha256sum "$OUT"
