# php2shell-guard 1.0.0

Ferramenta emergencial para Debian/Ubuntu. Faz auditoria indicativa das versões PHP e, no modo automático, ativa uma mitigação Apache temporária quando encontra versões abaixo dos limites upstream configurados.

## Instalação

```bash
sudo apt install ./php2shell-guard_1.0.0_all.deb
```

## Comandos

```bash
sudo php2shell-guard              # audita e mitiga automaticamente se detectar versão potencialmente afetada
sudo php2shell-guard --check      # somente auditoria; não altera configuração
sudo php2shell-guard --apply      # força a mitigação, mesmo sem indício detectado
sudo php2shell-guard --status     # estado atual
sudo php2shell-guard --rollback   # remove a mitigação e restaura o estado anterior
```

Relatórios são gravados em `/var/log/php2shell-guard/`. O estado necessário para rollback fica em `/var/lib/php2shell-guard/`.

## Limitações importantes

- O verificador compara versões encontradas com versões corrigidas upstream: PHP 8.2.35, 8.3.36, 8.4.27 e 8.5.12.
- Debian/Ubuntu podem aplicar correções retroportadas sem elevar a versão upstream. Isso pode gerar falso positivo. Confira os avisos/changelogs de segurança da distribuição antes de concluir que o sistema está vulnerável.
- A ferramenta identifica binários PHP CLI e pacotes `php*-fpm`/`libapache2-mod-php*`; não garante que tenha identificado runtimes em containers, instalações manuais, chroots ou serviços externos.
- A mitigação não corrige o PHP. Ela bloqueia requisições `multipart` nos VirtualHosts Apache selecionados (o modo automático seleciona `all`) e pode interromper uploads legítimos.
- A mitigação é apenas temporária e não é uma solução completa para CVE-2026-109618/CVE-2026-109619. Atualize o PHP para pacotes corrigidos do fornecedor o quanto antes.
- A instalação do pacote não altera a configuração do servidor. A mitigação só é tentada quando o executável é executado.
- Se o Apache não estiver instalado/ativo, a auditoria ainda pode ser gerada, mas nenhuma mitigação Apache será aplicada.

## Desinstalação

Primeiro, se desejar remover as alterações de mitigação, execute:

```bash
sudo php2shell-guard --rollback
```

Depois remova o pacote:

```bash
sudo apt remove php2shell-guard
```

A remoção do pacote não executa rollback automaticamente, para evitar alterações inesperadas em um servidor de produção.
